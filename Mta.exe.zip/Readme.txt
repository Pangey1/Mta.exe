
███╗░░░███╗████████╗░█████╗░
████╗░████║╚══██╔══╝██╔══██╗
██╔████╔██║░░░██║░░░███████║
██║╚██╔╝██║░░░██║░░░██╔══██║
██║░╚═╝░██║░░░██║░░░██║░░██║
╚═╝░░░░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝
My new GDI malware in C++
If you run this without "safety" mode enabled, it will block Task Manager, the Registry, and CMD, and will COMPLETELY wipe your PC. 
I take no responsibility for any damage or loss of your data.